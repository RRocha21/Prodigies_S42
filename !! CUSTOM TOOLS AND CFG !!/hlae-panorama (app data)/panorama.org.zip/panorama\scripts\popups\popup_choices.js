'use strict';

var PopupChoices = ( function(){

	var _Init = function ()
	{
	}

	return {
		Init					: _Init,
	}

})();

(function()
{
})();
